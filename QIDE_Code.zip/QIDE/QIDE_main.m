clear; clc;
format long;
addpath(genpath(pwd));

runs = 1;

% CEC2017的29个测试函数编号 (共29个函数, 排除F2)
func_list = [ 1, 3, 4, 5, 6, 7, 8, 9, 10, ...
             11, 12, 13, 14, 15, 16, 17, 18, 19, 20, ...
             21, 22, 23, 24, 25, 26, 27, 28, 29, 30];
fun_nums = length(func_list);  % 29

% CEC2017各函数的全局最优值
targetbest = zeros(1, 31);
targetbest(1) = 100;    % F1
targetbest(3) = 300;    % F3
targetbest(4) = 400;    % F4
targetbest(5) = 500;    % F5
targetbest(6) = 600;    % F6
targetbest(7) = 700;    % F7
targetbest(8) = 800;    % F8
targetbest(9) = 900;    % F9
targetbest(10) = 1000;  % F10
targetbest(11) = 1100;  % F11
targetbest(12) = 1200;  % F12
targetbest(13) = 1300;  % F13
targetbest(14) = 1400;  % F14
targetbest(15) = 1500;  % F15
targetbest(16) = 1600;  % F16
targetbest(17) = 1700;  % F17
targetbest(18) = 1800;  % F18
targetbest(19) = 1900;  % F19
targetbest(20) = 2000;  % F20
targetbest(21) = 2100;  % F21
targetbest(22) = 2200;  % F22
targetbest(23) = 2300;  % F23
targetbest(24) = 2400;  % F24
targetbest(25) = 2500;  % F25
targetbest(26) = 2600;  % F26
targetbest(27) = 2700;  % F27
targetbest(28) = 2800;  % F28
targetbest(29) = 2900;  % F29
targetbest(30) = 3000;  % F30

fbest   = Inf * ones(fun_nums, runs);
f_error = Inf * ones(fun_nums, runs);
f_mean   = Inf * ones(fun_nums, 1);
f_median = Inf * ones(fun_nums, 1);
f_std    = Inf * ones(fun_nums, 1);
Time = zeros(fun_nums, runs);

fhd = str2func('cec17_func');

for D = 50
    nfe_max = 10000 * D;
    Bd = [100; -100];

    xbest = Inf * ones(runs, D);

    convFold = ['Conver', num2str(D), 'D'];
    if ~exist(convFold, 'dir')
        mkdir(convFold);
    end

    fname = ['QIDE_', num2str(D), 'D.txt'];
    f_out = fopen(fname, 'wt');

    fMedian = ['QIDE_', num2str(D), 'D_locMedian.txt'];
    f_loc = fopen(fMedian, 'wt');
    curve = zeros(fun_nums,nfe_max);

    for i = 1:fun_nums
        fun_num = func_list(i);
        disp(['fid:', num2str(fun_num)]);
        fprintf(f_out, 'fid:%d\n', fun_num);
        fprintf(f_loc, 'fid:%d\n', fun_num);

        for j = 1:runs
            [gbest, gbestval, FES, RecordT] = QIDE_func(fhd, D, nfe_max, Bd, fun_num, j);
            xbest(j, :) = gbest;
            fbest(i, j) = gbestval;
            disp(['x[', num2str(gbest), ']=', num2str(gbestval - targetbest(fun_num), 15)]);
            fprintf(f_out, 'x[%s]=%s\n', num2str(gbest), num2str(gbestval - targetbest(fun_num)));
            Time(i, j) = RecordT;
        end
        curve(i,:) = FES; 
        [bestval, best] = min(fbest(i, :));
        loc = xbest(best, :);
        disp(['Best[', num2str(loc), ']=', num2str(bestval - targetbest(fun_num), 15)]);
        fprintf(f_out, 'Best[%s]=%s\n', num2str(loc), num2str(bestval - targetbest(fun_num)));

        f_error(i, :) = fbest(i, :) - targetbest(fun_num);
        f_mean(i) = mean(f_error(i, :));
        f_median(i) = median(f_error(i, :));

        [value, index] = sort(f_error(i, :));
        if mod(runs, 2) == 0
            locMedian = [index(runs/2), index(runs/2 + 1)];
        else
            locMedian = index(ceil(runs/2));
        end
        fprintf(f_loc, 'LocMedian = %s\n', num2str(locMedian));

        f_std(i) = std(f_error(i, :));

        disp(['mean[', num2str(i), ']=', num2str(f_mean(i), 15)]);
        fprintf(f_out, 'mean[%s]=%s\n', num2str(i), num2str(f_mean(i)));
        disp(['median[', num2str(i), ']=', num2str(f_median(i), 15)]);
        fprintf(f_out, 'median[%s]=%s\n', num2str(i), num2str(f_median(i)));
        disp(['std[', num2str(i), ']=', num2str(f_std(i), 15)]);
        fprintf(f_out, 'std[%s]=%s\n', num2str(i), num2str(f_std(i)));

        % 匹配QIDE生成的日志文件名格式
        medianFile = ['QIDE_fid_', num2str(fun_num), '_', num2str(D), 'D_', num2str(locMedian), '.dat'];
        targetFile = ['.\', convFold, '\', medianFile];
        % copyfile(medianFile, targetFile);
    end

    fclose(f_out);
    fclose(f_loc);
end
